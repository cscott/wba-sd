//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sd.rc
//
#define IDR_MENU1                       101
#define IDD_ABOUTBOX                    102
#define IDD_TEXTENTRY                   103
#define IDD_START_DIALOG                104
#define IDD_TEXT_ENTRY_DIALOG           106
#define IDD_PRINTING_DIALOG             107
#define IDB_BITMAP1                     108
#define IDI_ICON1                       109
#define IDI_ICON2                       110
#define IDI_ICON3                       111
#define IDI_ICON4                       112
#define IDI_ICON5                       113
#define IDI_ICON6                       114
#define IDI_ICON7                       115
#define IDI_ICON8                       116
#define IDC_FILENAME                    1000
#define IDC_FILE_ACCEPT                 1003
#define IDC_FILE_EDIT                   1004
#define IDC_FILE_TEXT1                  1005
#define IDC_FILE_TEXT2                  1006
#define IDC_FILE_CANCEL                 1007
#define IDC_START_CAPTION               1008
#define IDC_START_LIST                  1009
#define IDC_START_ACCEPT                1010
#define IDC_START_CANCEL                1011
#define IDC_OUTPUT_NAME                 1012
#define IDC_DEFAULT                     1013
#define IDC_USERDEFINED                 1014
#define IDC_DATABASE_NAME               1016
#define IDC_NORMAL                      1019
#define IDC_WRITE_LIST                  1020
#define IDC_WRITE_FULL_LIST             1021
#define IDC_ABRIDGE                     1022
#define IDC_CANCEL_ABRIDGE              1023
#define IDC_ABRIDGE_NAME                1024
#define IDC_START_DELETE_SESSION_CHECKED 1025
#define IDC_SEQ_NUM_OVERRIDE            1026
#define IDC_SEQ_NUM_OVERRIDE_SPIN       1027
#define IDC_START_PROGRESS              1039
#define ID_FILE_CHOOSE_FONT             40001
#define ID_FILE_PRINTTHIS               40002
#define ID_FILE_PRINTFILE               40003
#define ID_FILE_EXIT                    40004
#define ID_HELP_ABOUTSD                 40005
#define ID_HELP_FAQ                     40006
#define ID_COMMAND_UNDO                 40007
#define ID_COMMAND_ABORTTHISSEQUENCE    40008
#define ID_COMMAND_ENDTHISSEQUENCE      40009
#define ID_COMMAND_RESOLVE              40010
#define ID_COMMAND_COMMENT              40011
#define ID_COMMAND_CH_OUTFILE           40012
#define ID_COMMAND_TOGGLE_CONC          40013
#define ID_COMMAND_TOGGLE_PHAN          40014
#define ID_COMMAND_DISCARD_CONCEPT      40015
#define ID_COMMAND_CH_TITLE             40016
#define ID_COMMAND_CLIPBOARD_CUT        40017
#define ID_COMMAND_CLIPBOARD_DEL_ALL    40018
#define ID_COMMAND_CLIPBOARD_DEL_ONE    40019
#define ID_COMMAND_CLIPBOARD_PASTE_ONE  40020
#define ID_COMMAND_CLIPBOARD_PASTE_ALL  40021
#define ID_COMMAND_KEEP_PICTURE         40022
#define ID_COMMAND_NORMALIZE            40023
#define ID_COMMAND_STANDARDIZE          40024
#define ID_COMMAND_RECONCILE            40025
#define ID_COMMAND_PICK_RANDOM          40026
#define ID_COMMAND_PICK_SIMPLE          40027
#define ID_COMMAND_PICK_CONCEPT         40028
#define ID_COMMAND_PICK_LEVEL           40029
#define ID_COMMAND_PICK_8P_LEVEL        40030
#define ID_COMMAND_CREATE_WAVES         40031
#define ID_COMMAND_CREATE_2FL           40032
#define ID_COMMAND_CREATE_LINESIN       40033
#define ID_COMMAND_CREATE_LINESOUT      40034
#define ID_COMMAND_CREATE_INVLINES      40035
#define ID_COMMAND_CREATE_3N1LINES      40036
#define ID_COMMAND_CREATE_ANYLINES      40037
#define ID_COMMAND_CREATE_COLUMNS       40038
#define ID_COMMAND_CREATE_MAGCOL        40039
#define ID_COMMAND_CREATE_GWV           40040
#define ID_COMMAND_CREATE_DPT           40041
#define ID_COMMAND_CREATE_CDPT          40042
#define ID_COMMAND_CREATE_8CH           40043
#define ID_COMMAND_CREATE_TRBY          40044
#define ID_COMMAND_CREATE_ANYCOLS       40045
#define ID_COMMAND_CREATE_ANY_TIDAL     40046
#define ID_COMMAND_CREATE_DMD           40047
#define ID_COMMAND_CREATE_QTAG          40048
#define ID_COMMAND_CREATE_3QTAG         40049
#define ID_COMMAND_CREATE_QLINE         40050
#define ID_COMMAND_CREATE_3QLINE        40051
#define ID_COMMAND_CREATE_ANY_QTAG      40052
#define ID_COMMAND_COPY_TEXT            40053
#define ID_COMMAND_CUT_TEXT             40054
#define ID_COMMAND_PASTE_TEXT           40055
#define ID_HELP_SDHELP                  40056

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40057
#define _APS_NEXT_CONTROL_VALUE         1040
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
